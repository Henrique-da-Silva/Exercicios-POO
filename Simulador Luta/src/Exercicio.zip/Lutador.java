public interface Lutador {

    void atacar(Lutador oponente);
    void defender(int dano);
    int obterVida();

}
